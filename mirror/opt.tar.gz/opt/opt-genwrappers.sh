#!/bin/sh
# Wrappers for Entware binaries in /tmp/opt: run each via the real loader
# (they hardcode /opt/lib/ld-linux.so.3) and point ncurses/mc/locale at real
# paths, since Entware compiles them for a /opt that can't exist on this box.
OPT=/tmp/opt; LD=$OPT/lib/ld-linux.so.3; LP=$OPT/lib:$OPT/usr/lib
WD=$OPT/wrappers; mkdir -p "$WD"; rm -f "$WD"/*
for d in bin sbin usr/bin usr/sbin; do
  [ -d "$OPT/$d" ] || continue
  for f in "$OPT/$d"/*; do
    [ -f "$f" ] && [ -x "$f" ] || continue
    n=$(basename "$f"); n=${n%.new}
    if grep -qa "ld-linux.so.3" "$f" 2>/dev/null; then
      { printf '#!/bin/sh\n'
        printf 'export TERMINFO=%s/share/terminfo TERMINFO_DIRS=%s/share/terminfo\n' "$OPT" "$OPT"
        printf 'export TMPDIR="${TMPDIR:-/tmp}" MC_DATADIR=%s/share/mc\n' "$OPT"
        printf 'export LOCPATH=%s/usr/lib/locale I18NPATH=%s/usr/share/i18n\n' "$OPT" "$OPT"
        printf '[ -n "$LC_CTYPE" ] || export LC_CTYPE=en_US.UTF-8\n'
        printf '[ -n "$TERM" ] || export TERM=vt100\n'
        printf 'exec %s --library-path %s "%s" "$@"\n' "$LD" "$LP" "$f"
      } > "$WD/$n"; chmod +x "$WD/$n"
    else ln -sf "$f" "$WD/$n"; fi
  done
done
